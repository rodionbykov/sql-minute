insert into locations (loc_no, loc_type, loc_name, address, city, state, postalcode, country)
values  (1, 'HQ', 'Main Headquarters', '476 5th Avenue', 'New York City', 'New York', '10018', 'United States'),
        (2, 'BRANCH', 'West Coast Branch', '630 W 5th Street', 'Los Angeles', 'California', '90071', 'United States'),
        (3, 'OFFICE', 'Denver Office', '10 W 14th Avenue Parkway', 'Denver', 'Colorado', '80204', 'United States'),
        (4, 'DIVISION', 'Canadian Division', '22 Yorkville Avenue', 'Toronto', 'Ontario', 'M4W 1L4', 'Canada'),
        (5, 'OFFICE', 'Mexican Office', '1 Coyoacán', 'México', 'México', '04510', 'Mexico'),
        (6, 'RHQ', 'European Headquarters', '10 Place du Panthéon', 'Paris', null, '75005', 'France'),
        (7, 'OFFICE', 'Poland Office', 'Koszykowa 26/28', 'Warsaw', 'mazowieckie', '00-950', 'Poland'),
        (8, 'OFFICE', 'Ukrainian Office', '3 Holosyiivskyi prospekt', 'Kyiv', null, '03039', 'Ukraine');