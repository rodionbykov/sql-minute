INSERT INTO departments (dept_no, dept_code, dept_name) VALUES (1, 'd001', 'Marketing');
INSERT INTO departments (dept_no, dept_code, dept_name) VALUES (2, 'd002', 'Finance');
INSERT INTO departments (dept_no, dept_code, dept_name) VALUES (3, 'd003', 'Human Resources');
INSERT INTO departments (dept_no, dept_code, dept_name) VALUES (4, 'd004', 'Production');
INSERT INTO departments (dept_no, dept_code, dept_name) VALUES (5, 'd005', 'Development');
INSERT INTO departments (dept_no, dept_code, dept_name) VALUES (6, 'd006', 'Quality Management');
INSERT INTO departments (dept_no, dept_code, dept_name) VALUES (7, 'd007', 'Sales');
INSERT INTO departments (dept_no, dept_code, dept_name) VALUES (8, 'd008', 'Research');
INSERT INTO departments (dept_no, dept_code, dept_name) VALUES (9, 'd009', 'Customer Service');
